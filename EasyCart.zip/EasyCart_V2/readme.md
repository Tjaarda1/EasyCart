funcion 1
comparar precios items
 
 params: 
	'arrayNames' array lista de compra (input del usuario).
	'supermarketId' 
 returns: precio para ese supermarket
 
Funcion 1 se usa en bucle con todos los supermercados cercanos al usuario. Nos quedamos con el mas barato.

 
 
 
 checkbox: 
 https://stackoverflow.com/questions/9763643/how-to-add-a-check-box-to-an-alert-dialog
